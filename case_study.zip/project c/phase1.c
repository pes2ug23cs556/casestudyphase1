#include<stdio.h>
#include<stdlib.h>

void new_user()
{
    char user_name[10];
    int user_id;
    long long int phone_no;
    printf("\n\nEnter the new username : ");
    scanf("%s",&user_name);
    printf("\nEnter the new user id : ");
    scanf("%d",&user_id);
    printf("\nEnter your phone number : ");
    scanf("%lld",&phone_no);
    printf("\n\n                ******** AVAILABLE ITEMS IN THE STORE ********\n\n");
    char a[][100]={"Apple","Mango","Books","Pen","Cookies","Powder","Haldirams_special","Ice-Cream","Coconut","Chocolates"};
    for(int i=0;i<10;i++)
    {
        printf("%d. %s\n",i+1,a[i]);
    }

    int items;
    printf("\nEnter the no items you want to shop : ");
    scanf("%d",&items);
    int total=0;
    for(int j=1;j<=items;j++)
    {
        int choice;
        printf("\n\nchoose the item you want to buy : ");
        scanf("%d",&choice);
        int qty=0;
        int price=0;
        switch(choice)
        {
            case 1:printf("Apple price is about 15/- for 1 pc");
                   printf("\nEnter the quantity : ");
                   scanf("%d",&qty);
                   price=qty*15;
                   break;
            case 2:printf("Mango price is about 20/- for 1 pc");
                   printf("\nEnter the quantity : ");
                   scanf("%d",&qty);
                   price=qty*20;
                   break;
            case 3:printf("Book price is about 40/- for 1 pc");
                   printf("\nEnter the quantity : ");
                   scanf("%d",&qty);
                   price=qty*40;
                   break;
            case 4:printf("Pen price is about 10/- for 1 pc");
                   printf("\nEnter the quantity : ");
                   scanf("%d",&qty);
                   price=qty*10;
                   break;
            case 5:printf("Cookies price is about 30/- for 1 pc");
                   printf("\nEnter the quantity : ");
                   scanf("%d",&qty);
                   price=qty*30;
                   break;
            case 6:printf("Powder price is about 25/- for 1 pc");
                   printf("\nEnter the quantity : ");
                   scanf("%d",&qty);
                   price=qty*25;
                   break;
            case 7:printf("Haldirams price is about 50/- for 1 pc");
                   printf("\nEnter the quantity : ");
                   scanf("%d",&qty);
                   price=qty*50;
                   break;
            case 8:printf("Icecream price is about 35/- for 1 pc");
                   printf("\nEnter the quantity : ");
                   scanf("%d",&qty);
                   price=qty*35;
                   break;
            case 9:printf("Coconut price is about 25/- for 1 pc");
                   printf("\nEnter the quantity : ");
                   scanf("%d",&qty);
                   price=qty*25;
                   break;
            case 10:printf("chocolates price is about 5/- for 1 pc");
                   printf("\nEnter the quantity : ");
                   scanf("%d",&qty);
                   price=qty*5;
                   break;
        }
        total=total+price;
    }
    printf("\n\nYour total amount is : %d/-",total);
    printf("\n\n\n            ******** THANK YOU FOR SHOPPING,VISIT AGAIN *********");
    return;
}

