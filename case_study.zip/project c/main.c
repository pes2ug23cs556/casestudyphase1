#include <stdio.h>
#include <stdlib.h>
#include "phase1.c"

int main()
{
    printf("                      --:WELCOME TO THE SHOPPING MART:--");
    new_user();
    return 0;
}